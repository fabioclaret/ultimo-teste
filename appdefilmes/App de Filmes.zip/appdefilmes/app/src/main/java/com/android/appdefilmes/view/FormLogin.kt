package com.android.appdefilmes.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.android.appdefilmes.R

class FormLogin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form_login)
    }
}